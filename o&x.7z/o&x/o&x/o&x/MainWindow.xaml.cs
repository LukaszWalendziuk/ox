﻿using System.Windows;
using System.Windows.Controls;

namespace o_x
{
    public partial class MainWindow : Window
    {
        private bool isPlayer1Turn = true; 
        private Button[,] buttons; 

        public MainWindow()
        {
            InitializeComponent();
            InitializeButtonsArray();
        }

        private void InitializeButtonsArray()
        {
            buttons = new Button[3, 3] { { Button00, Button01, Button02 },
                                          { Button10, Button11, Button12 },
                                          { Button20, Button21, Button22 } };
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            if (button.Content == null)
            {
                button.Content = isPlayer1Turn ? "X" : "O";
                isPlayer1Turn = !isPlayer1Turn;
                CheckForWinner();
            }
        }

        private void CheckForWinner()
        {
            
            for (int row = 0; row < 3; row++)
            {
                if (buttons[row, 0].Content != null &&
                    buttons[row, 0].Content == buttons[row, 1].Content &&
                    buttons[row, 1].Content == buttons[row, 2].Content)
                {
                    DeclareWinner((string)buttons[row, 0].Content);
                    return;
                }
            }

            for (int col = 0; col < 3; col++)
            {
                if (buttons[0, col].Content != null &&
                    buttons[0, col].Content == buttons[1, col].Content &&
                    buttons[1, col].Content == buttons[2, col].Content)
                {
                    DeclareWinner((string)buttons[0, col].Content);
                    return;
                }
            }

            if (buttons[0, 0].Content != null &&
                buttons[0, 0].Content == buttons[1, 1].Content &&
                buttons[1, 1].Content == buttons[2, 2].Content)
            {
                DeclareWinner((string)buttons[0, 0].Content);
                return;
            }

            if (buttons[0, 2].Content != null &&
                buttons[0, 2].Content == buttons[1, 1].Content &&
                buttons[1, 1].Content == buttons[2, 0].Content)
            {
                DeclareWinner((string)buttons[0, 2].Content);
                return;
            }

            bool isDraw = true;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (buttons[i, j].Content == null)
                    {
                        isDraw = false;
                        break;
                    }
                }
                if (!isDraw)
                    break;
            }

            if (isDraw)
            {
                MessageBox.Show("Remis!");
                ResetGame();
                return;
            }
        }

        private void DeclareWinner(string winner)
        {
            MessageBox.Show($"Gracz {winner} wygrywa!");
            ResetGame();
        }

        private void ResetGame()
        {
            foreach (Button button in buttons)
            {
                button.Content = null;
            }
            isPlayer1Turn = true;
        }
    }
}
